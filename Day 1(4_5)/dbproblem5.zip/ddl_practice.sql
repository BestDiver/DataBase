CREATE TABLE users (
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    age INTEGER NOT NULL,
    country TEXT NOT NULL,
    phone TEXT NOT NULL,
    balance INTEGER NOT NULL
);




-- 나이가 어린 순서대로 조회
-- 페이지당 출력되는 데이터가 20개일때,
-- 3번째 페이지를 조회하는 쿼리 41~60

SELECT rowid,age,first_name, phone, country FROM users
ORDER BY age ASC
LIMIT 20 OFFSET 40;


