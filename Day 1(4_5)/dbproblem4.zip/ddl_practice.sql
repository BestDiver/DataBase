CREATE TABLE users (
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    age INTEGER NOT NULL,
    country TEXT NOT NULL,
    phone TEXT NOT NULL,
    balance INTEGER NOT NULL
);




-- 전화번호 중간 4자리가 51로 시작
-- 지역이 서울이 아닌 사람들
-- 이름,전화번호, 사는 곳

SELECT first_name, phone, country FROM users
WHERE NOT country="서울"
AND phone LIKE '%-51__-%';


