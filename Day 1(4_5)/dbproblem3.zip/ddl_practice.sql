CREATE TABLE users (
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    age INTEGER NOT NULL,
    country TEXT NOT NULL,
    phone TEXT NOT NULL,
    balance INTEGER NOT NULL
);

-- 이름이 건우이고 지역정보가 경기도인 사람
SELECT first_name,age,country FROM users
WHERE first_name="건우"
AND country="경기도";




-- 경기도 혹은 강원도에 살지 않으면서 나이가 20~30살인 사람 나이 오름차순
SELECT first_name,last_name,age,country FROM users

WHERE NOT country="경기도" AND NOT country="강원도"
AND age BETWEEN 20 and 30
ORDER BY age ASC;

